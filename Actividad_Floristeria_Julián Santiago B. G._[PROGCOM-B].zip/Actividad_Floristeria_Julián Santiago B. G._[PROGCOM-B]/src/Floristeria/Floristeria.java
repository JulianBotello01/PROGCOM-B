package Floristeria;

public class Floristeria {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Casa julianCasa= new Casa("Amarilla con azul",5,2,true,true);
		System.out.println(julianCasa.describir());
		julianCasa.pintar(" Rojo con blanco y verde");
		System.out.println(julianCasa.describir());
	}
}
