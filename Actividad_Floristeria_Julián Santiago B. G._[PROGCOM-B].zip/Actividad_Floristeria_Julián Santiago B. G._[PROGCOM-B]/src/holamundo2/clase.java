package holamundo2;

public class clase {
	System.out.println("Hola mundo");
}
